
const socket = io();
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let players = {};
let keys = {};
let lastTime = performance.now();
let fps = 0;

document.addEventListener('keydown', e => {
    keys[e.key.toLowerCase()] = true;
    if (e.key.toLowerCase() === ' ') socket.emit('split');
});

document.addEventListener('keyup', e => {
    keys[e.key.toLowerCase()] = false;
});

socket.on('update', serverPlayers => {
    players = serverPlayers;
});

function update() {
    let dx = 0, dy = 0;

    if (keys['w']) dy -= 1;
    if (keys['s']) dy += 1;
    if (keys['a']) dx -= 1;
    if (keys['d']) dx += 1;

    socket.emit('move', {dx, dy});
}

function draw() {
    ctx.clearRect(0,0,canvas.width,canvas.height);

    for (let id in players) {
        let p = players[id];
        ctx.beginPath();
        ctx.arc(p.x % canvas.width, p.y % canvas.height, p.mass, 0, Math.PI*2);
        ctx.fillStyle = "#3498db";
        ctx.fill();
    }
}

function loop() {
    update();
    draw();

    let now = performance.now();
    fps = Math.round(1000 / (now - lastTime));
    lastTime = now;
    document.getElementById("stats").innerText = "FPS: " + fps;

    requestAnimationFrame(loop);
}

loop();
